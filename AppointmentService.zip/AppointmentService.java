import java.util.Scanner;
	
public class AppointmentService {
	Scanner first = new Scanner(System.in);
	Scanner descrip = new Scanner(System.in);
		
	public Appointment addAppointment() {
	Appointment apprecord = new Appointment(null, null);
		return apprecord;
	}
	public static Appointment deleteAppointment() {
		appecord = apprecord.deleteAppointment(apprecord);
		return null;
	}
}